import { useState, useCallback } from "react";

export interface Message {
  role: "user" | "assistant" | "system";
  content: string;
}

export interface UseOllamaReturn {
  sendMessage: (messages: Message[]) => Promise<string>;
  loading: boolean;
  error: string | null;
  checkHealth: () => Promise<boolean>;
}

export function useOllama(): UseOllamaReturn {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sendMessage = useCallback(async (messages: Message[]): Promise<string> => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ messages }),
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();

      if (data.message && data.message.content) {
        return data.message.content;
      }

      throw new Error("No response content from Ollama");
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const checkHealth = useCallback(async (): Promise<boolean> => {
    try {
      const response = await fetch("/api/health");
      return response.ok;
    } catch {
      return false;
    }
  }, []);

  return {
    sendMessage,
    loading,
    error,
    checkHealth,
  };
}
