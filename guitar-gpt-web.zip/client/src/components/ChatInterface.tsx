import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Send, AlertCircle, Menu, X } from "lucide-react";
import { useOllama, Message } from "@/hooks/useOllama";

interface ChatThread {
  id: string;
  title: string;
  messages: Message[];
}

export default function ChatInterface() {
  const [threads, setThreads] = useState<ChatThread[]>([
    {
      id: "1",
      title: "Chat 1",
      messages: [
        {
          role: "system",
          content:
            "You are a helpful guitar expert AI assistant. Help users with guitar techniques, music theory, equipment recommendations, and songwriting advice.",
        },
      ],
    },
  ]);

  const [activeThreadId, setActiveThreadId] = useState("1");
  const [inputValue, setInputValue] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { sendMessage, loading, error, checkHealth } = useOllama();
  const [ollamaConnected, setOllamaConnected] = useState(false);

  const activeThread = threads.find((t) => t.id === activeThreadId);
  const visibleMessages = activeThread?.messages.filter((m) => m.role !== "system") || [];

  // Check Ollama health on mount
  useEffect(() => {
    checkHealth().then(setOllamaConnected);
  }, [checkHealth]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [visibleMessages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || !activeThread || loading) return;

    const userMessage: Message = {
      role: "user",
      content: inputValue.trim(),
    };

    // Add user message to thread
    const updatedMessages = [...activeThread.messages, userMessage];
    setThreads((prev) =>
      prev.map((t) => (t.id === activeThreadId ? { ...t, messages: updatedMessages } : t))
    );
    setInputValue("");

    try {
      // Send to Ollama
      const assistantResponse = await sendMessage(updatedMessages);

      const assistantMessage: Message = {
        role: "assistant",
        content: assistantResponse,
      };

      // Add assistant response
      setThreads((prev) =>
        prev.map((t) =>
          t.id === activeThreadId
            ? { ...t, messages: [...updatedMessages, assistantMessage] }
            : t
        )
      );
    } catch (err) {
      console.error("Failed to get response:", err);
    }
  };

  const handleNewChat = () => {
    const newId = Date.now().toString();
    const newThread: ChatThread = {
      id: newId,
      title: `Chat ${threads.length + 1}`,
      messages: [
        {
          role: "system",
          content:
            "You are a helpful guitar expert AI assistant. Help users with guitar techniques, music theory, equipment recommendations, and songwriting advice.",
        },
      ],
    };
    setThreads((prev) => [newThread, ...prev]);
    setActiveThreadId(newId);
  };

  const handleClearChats = () => {
    setThreads([
      {
        id: "1",
        title: "Chat 1",
        messages: [
          {
            role: "system",
            content:
              "You are a helpful guitar expert AI assistant. Help users with guitar techniques, music theory, equipment recommendations, and songwriting advice.",
          },
        ],
      },
    ]);
    setActiveThreadId("1");
  };

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? "w-64" : "w-0"
        } bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 overflow-hidden`}
      >
        <div className="p-4 border-b border-sidebar-border flex items-center gap-3">
          <img
            src="/manus-storage/icon_3606a2f9.png"
            alt="guitarGPT"
            className="w-10 h-10 rounded-lg object-cover"
          />
          <h1 className="text-xl font-bold text-sidebar-foreground">guitarGPT</h1>
        </div>

        <button
          onClick={handleNewChat}
          className="m-4 px-4 py-2 bg-sidebar-primary text-sidebar-primary-foreground rounded-lg hover:opacity-90 transition-smooth font-medium"
        >
          + New Chat
        </button>

        <div className="flex-1 overflow-y-auto px-2">
          {threads.map((thread) => (
            <button
              key={thread.id}
              onClick={() => setActiveThreadId(thread.id)}
              className={`w-full text-left px-3 py-2 rounded-lg mb-2 transition-smooth ${
                activeThreadId === thread.id
                  ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                  : "text-sidebar-foreground hover:bg-sidebar-border"
              }`}
            >
              <p className="truncate text-sm">{thread.title}</p>
            </button>
          ))}
        </div>

        <div className="p-4 border-t border-sidebar-border space-y-2">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="w-full px-3 py-2 text-sm text-sidebar-foreground hover:bg-sidebar-border rounded-lg transition-smooth"
          >
            ⚙️ Settings
          </button>
          <button
            onClick={handleClearChats}
            className="w-full px-3 py-2 text-sm text-destructive hover:bg-destructive/10 rounded-lg transition-smooth"
          >
            Clear All
          </button>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="bg-card border-b border-border p-4 flex justify-between items-center shadow-sm">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-muted rounded-lg transition-smooth lg:hidden"
            >
              {sidebarOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>
            <h2 className="text-lg font-semibold text-foreground">
              {activeThread?.title || "Chat"}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            {ollamaConnected ? (
              <span className="text-xs text-green-600 font-medium">✓ Connected</span>
            ) : (
              <span className="text-xs text-destructive font-medium">✗ Disconnected</span>
            )}
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gradient-to-b from-background to-muted/20">
          {visibleMessages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <img
                src="/manus-storage/screenshot_1e4f8a64.png"
                alt="guitarGPT"
                className="w-32 h-32 mb-6 rounded-lg object-cover shadow-lg"
              />
              <h3 className="text-2xl font-bold text-foreground mb-2">Start a conversation</h3>
              <p className="text-muted-foreground max-w-sm">
                Ask me anything about guitar techniques, music theory, equipment recommendations, or songwriting advice!
              </p>
            </div>
          ) : (
            visibleMessages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} animate-in fade-in slide-in-from-bottom-2 duration-300`}
              >
                <div
                  className={`message-bubble max-w-md lg:max-w-lg ${
                    msg.role === "user"
                      ? "message-user shadow-md"
                      : "message-assistant shadow-sm"
                  }`}
                >
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                </div>
              </div>
            ))
          )}

          {loading && (
            <div className="flex justify-start animate-in fade-in duration-300">
              <div className="message-bubble message-assistant flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm">Thinking...</span>
              </div>
            </div>
          )}

          {error && (
            <div className="flex justify-start animate-in fade-in duration-300">
              <div className="message-bubble bg-destructive text-destructive-foreground flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <p className="text-sm">{error}</p>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="bg-card border-t border-border p-4 shadow-lg">
          <div className="flex gap-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder="Type your message... (Shift+Enter for new line)"
              disabled={loading || !ollamaConnected}
              className="flex-1 bg-input"
            />
            <Button
              onClick={handleSendMessage}
              disabled={loading || !inputValue.trim() || !ollamaConnected}
              size="icon"
              className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-md"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          {!ollamaConnected && (
            <p className="text-xs text-destructive mt-2 flex items-center gap-1">
              <AlertCircle className="w-3 h-3" />
              Cannot connect to Ollama. Make sure it's running on 127.0.0.1:11434
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
