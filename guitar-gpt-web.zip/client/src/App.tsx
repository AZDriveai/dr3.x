import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "./contexts/ThemeContext";
import ChatInterface from "@/components/ChatInterface";

function App() {
  return (
    <ThemeProvider defaultTheme="light">
      <TooltipProvider>
        <Toaster />
        <ChatInterface />
      </TooltipProvider>
    </ThemeProvider>
  );
}

export default App;
