# guitarGPT Web - Design Concepts

## Design Philosophy Selected: Modern Minimalist with Warm Accents

This design approach prioritizes **clarity, accessibility, and conversational warmth** for a music-focused AI chat application.

### Core Design Principles

1. **Conversational Clarity**: Clean, spacious chat interface that centers the conversation
2. **Musical Identity**: Subtle guitar-inspired visual elements and warm color palette
3. **Functional Minimalism**: Remove unnecessary UI chrome; let content speak
4. **Responsive Depth**: Soft shadows and subtle transitions create dimension without clutter

### Color Philosophy

- **Primary**: Deep amber/warm orange (`#D97706`) - evokes guitar wood and warmth
- **Background**: Off-white (`#F9FAFB`) - reduces eye strain, maintains focus on content
- **Accent**: Slate blue (`#475569`) - professional, pairs well with warm tones
- **Text**: Dark slate (`#1E293B`) - excellent contrast, readable
- **Borders**: Light gray (`#E2E8F0`) - subtle structure without heaviness

### Layout Paradigm

- **Asymmetric Sidebar Layout**: Left sidebar (narrow, 240px) for chat history; main area for conversation
- **Vertical Flow**: Messages stack naturally; input bar fixed at bottom
- **Breathing Room**: Generous padding (24px) around content areas
- **No Center-Lock**: Sidebar-main split creates dynamic visual balance

### Signature Elements

1. **Chat Bubbles**: Rounded corners (12px), soft shadows, color-coded (user: amber, assistant: slate)
2. **Guitar Icon**: Subtle musical note/guitar motif in header and empty states
3. **Smooth Transitions**: 300ms ease-in-out for message entrance, hover effects on buttons

### Interaction Philosophy

- **Immediate Feedback**: Buttons show pressed state instantly
- **Conversational Pacing**: Messages appear with gentle fade-in
- **Accessible Focus**: Clear focus rings for keyboard navigation
- **Loading States**: Subtle spinner with breathing animation

### Animation Guidelines

- **Message Entrance**: Fade-in + subtle slide-up (300ms)
- **Button Hover**: Slight scale (1.02x) + color shift
- **Transitions**: All state changes use 300ms ease-in-out
- **Loading**: Continuous pulse animation for spinners

### Typography System

- **Display**: Geist or system sans-serif, bold (700), 24-32px - headers
- **Body**: System sans-serif, regular (400), 14-16px - messages, UI text
- **Monospace**: For any code/technical content (if needed)
- **Hierarchy**: Bold headers, regular body, muted secondary text

---

## Implementation Notes

- Sidebar collapses on mobile (hamburger menu)
- Chat input grows with content (textarea auto-expand)
- Settings modal for API key management
- Empty state with guitar graphic when no chats exist
- Dark mode support (optional toggle in settings)
