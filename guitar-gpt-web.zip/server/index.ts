import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Middleware
  app.use(express.json());

  // Ollama API proxy endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages } = req.body;

      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Invalid messages format" });
      }

      // Call Ollama API on localhost:11434
      const response = await fetch("http://127.0.0.1:11434/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "llama2",
          messages: messages,
          stream: false,
          temperature: 0.5,
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        console.error("Ollama API error:", error);
        return res.status(response.status).json({ error: "Ollama API error" });
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ error: "Failed to process chat request" });
    }
  });

  // Health check endpoint
  app.get("/api/health", async (req, res) => {
    try {
      const response = await fetch("http://127.0.0.1:11434/api/tags");
      if (response.ok) {
        res.json({ status: "ok", ollama: "connected" });
      } else {
        res.status(503).json({ status: "error", message: "Ollama not responding" });
      }
    } catch (error) {
      res.status(503).json({ status: "error", message: "Cannot connect to Ollama" });
    }
  });

  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));

  // Handle client-side routing - serve index.html for all routes
  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = process.env.PORT || 3000;

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
    console.log(`Ollama endpoint: http://127.0.0.1:11434`);
  });
}

startServer().catch(console.error);
